﻿using Database2022.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Database2022
{
    class FacturaService
    {
        private readonly AppDbContext _context;

        public FacturaService() => _context = App.GetContext();

        public bool Create(Compra item)
        {
            try
            {
                // Entity Framework Core
                _context.Factura.Add(item);
                _context.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool CreateRange(List<Compra> items)
        {
            try
            {
                // Entity Framework Core
                _context.Factura.AddRange(items);
                _context.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public List<Compra> Get()
        {
            return _context.Factura.ToList();
        }

        public List<Compra> GetByText(string text)
        {
            return _context.Factura.Where(x => x.Cliente.Contains(text)).ToList();
        }


    }
}
