﻿using Database2022.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace Database2022.ViewModels
{
    public class ViewModelFactura : BaseViewModel
    {
        private string color;
        public string Color
        {
            get { return this.color; }
            set { SetValue(ref this.color, value); }
        }

        private string filter;
        public string Filter
        {
            get { return this.filter; }
            set { SetValue(ref this.filter, value); }
        }

        private List<Compra> factura;
        public List<Compra> Factura
        {
            get { return this.factura; }
            set { SetValue(ref this.factura, value); }
        }

        public ICommand SearchCommand { get; set; }

        public ViewModelFactura()
        {
            SearchCommand = new Command(() =>
            {
                FacturaService service = new FacturaService();
                Factura = service.GetByText(Filter);

                // Puedes ajustar la lógica para cambiar el color según tus necesidades.
                if (Factura.Count > 3)
                    Color = "Red";
                else
                    Color = "Blue";
            });
        }
    }
}
