﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Database2022.Models
{
    public class Compra
    {
        public int CompraId { get; set; }
        public DateTime Fecha { get; set; }
        public string Cliente { get; set; }
        public decimal Total { get; set; }
        public string Vendedor { get; set; }
    }
}
